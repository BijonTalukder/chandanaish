package com.prio.chandanaish;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class itihash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itihash);
    }
}